from django.shortcuts import render, redirect
from django.forms import inlineformset_factory

from .models import *
from .forms import *
# Create your views here.

def index(request):
    return render(request, 'app/index.html')

def about(request):
    return render(request, 'app/about.html')

def contact(request):
    if request.method == "POST":
        emri = request.POST.get('emri')
        email = request.POST.get('email')
        message = request.POST.get('message')

        Contact.objects.create(
            emri=emri,
            email=email,
            message=message
        )

        return redirect('index')
        
    return render(request, 'app/contact.html')

def register(request):
    form = CreateUserForm()

    if request.method == "POST":
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
        
    context = {
        'form':form
    }

    return render(request, 'auth/register.html', context)

def login(request):
    return render(request, 'auth/login.html')



def feed(request):
    return render(request, 'app/feed.html')

def not_found(request, *args, **kwargs):
    #return redirect('index')
    return render(request, 'error/not_found.html')