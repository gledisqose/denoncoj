from django.db import models
from django.contrib.auth.models import User
from django.urls import reverse
from datetime import date, datetime

from ckeditor.fields import RichTextField

# Create your models here.
class Contact(models.Model):
    emri = models.CharField(max_length=30, null=True)
    email = models.EmailField(null=True)
    message = models.TextField(max_length=220, null=True)
    date_added = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return str(self.emri)

class Post(models.Model):
    title = models.CharField(max_length=255)
    body = RichTextField(blank=True, null=True)
    author = models.ForeignKey(User, on_delete=models.CASCADE, blank=True)
    post_date = models.DateField(auto_now_add=True)
    likes = models.ManyToManyField(User, related_name='blog_post')

    def total_likes(self):
        return self.likes.count()

    def __str__(self):
        return self.title + ' | ' + str(self.author)