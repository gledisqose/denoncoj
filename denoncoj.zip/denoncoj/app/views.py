from django.shortcuts import render, redirect

# Create your views here.

def index(request):
    return render(request, 'app/index.html')
def feed(request):

    return render(request, 'app/feed.html')

def not_found(request, *args, **kwargs):
    #return redirect('index')
    return render(request, 'error/not_found.html')