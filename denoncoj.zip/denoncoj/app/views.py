from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.forms import inlineformset_factory
from django.contrib.auth.forms import UserCreationForm

from django.contrib.auth import authenticate, login, logout

from django.contrib import messages

from django.contrib.auth.decorators import login_required

from .models import *
from .forms import *

from django.core.mail import EmailMessage
from django.conf import settings
from django.template.loader import render_to_string
from django.core.mail import send_mail
# Create your views here.

def index(request):
    return render(request, 'app/index.html')

def about(request):
    return render(request, 'app/about.html')

def contact(request):
    if request.method == "POST":
        emri = request.POST.get('emri')
        email = request.POST.get('email')
        message = request.POST.get('message')

        Contact.objects.create(
            emri=emri,
            email=email,
            message=message
        )

        return redirect('index')
        
    return render(request, 'app/contact.html')

def register(request):
    if request.user.is_authenticated == False:
        form = CreateUserForm()
        if request.method == "POST":
            form = CreateUserForm(request.POST)
            if form.is_valid():
                form.save()
                user = form.cleaned_data.get('username')
                messages.success(request, 'Llogaria u krijua për '+ user)                
                return redirect('login')

        context = {
            'form':form,
        }
        return render(request, 'auth/register.html', context)
    else:
        return redirect('index')

def loginPage(request):
    if request.user.is_authenticated == False:
        if request.method == "POST":
            username = request.POST.get('username')
            password = request.POST.get('password')

            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('dashboard')
            else:
                messages.info(request, "Username ose Password është gabim!")
                context = {}
                return render(request, 'auth/login.html', context) 

        context = {}
        return render(request, 'auth/login.html', context)
    else:
        return redirect('index')

def logoutUser(request):
    logout(request)
    return redirect('login')

def feed(request):
    return render(request, 'app/feed.html')

@login_required(login_url='login')
def userDashboard(request):
    posts = Post.objects.filter(author=request.user)

    context = {
        'posts':posts
    }

    return render(request, 'dashboard/user_dashboard.html', context)

@login_required(login_url='login')
def post(request):
    form = PostForm()
    if request.method == "POST":
        form = PostForm(request.POST, request.FILES)
        if form.is_valid():
            form.save(commit=False)
            form.instance.author = request.user
            form.save()

            return redirect('dashboard')

    context = {
        'form':form
    }

    return render(request, 'dashboard/post-form.html', context)

def not_found(request, *args, **kwargs):
    #return redirect('index')
    return render(request, 'error/not_found.html')