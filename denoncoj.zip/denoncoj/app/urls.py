from django.urls import path

from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('about', views.about, name='about'),
    path('contact', views.contact, name='contact'),
    path('feed', views.feed, name='feed'),
    path('login/', views.loginPage, name='login'),
    path('register', views.register, name='register'),    
    path('logout/', views.logoutUser, name='logout'),

    path('dashboard', views.userDashboard, name='dashboard'),
]