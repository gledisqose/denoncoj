from django.urls import path

from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('about', views.about, name='about'),
    path('contact', views.contact, name='contact'),
    path('feed', views.feed, name='feed'),
    path('login/', views.loginPage, name='login'),
    path('register', views.register, name='register'),    
    path('logout/', views.logoutUser, name='logout'),

    path('dashboard', views.userDashboard, name='dashboard'),

    # pathet per posteve (fillimi)
    path('post', views.post, name='post'),
    path('edit/<uuid:pk>', views.post_edit, name='post_edit'),
    path('delete/<uuid:pk>', views.post_delete, name='post_delete'),

    # pathet per posteve (mbarimi)
]